package com.example.workouttimerapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Chronometer;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity<paused> extends AppCompatActivity {
    Chronometer timer;
    long delay;
    boolean isRunning;
    EditText workoutEditText;
    SharedPreferences sharedPreferences;
    String WORK_OUT_TYPE;
    TextView displayTimeSpentAndWorkout;
    long convertTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        workoutEditText = findViewById(R.id.workoutEditText);
        displayTimeSpentAndWorkout = findViewById(R.id.displayTimeSpentAndWorkout);
        timer = findViewById(R.id.timer);
        sharedPreferences = getSharedPreferences("com.example.workouttimerapp", MODE_PRIVATE);
        CheckSharedPreferences();

        if (savedInstanceState != null) {

            convertTime = savedInstanceState.getLong("CONVERT_TIME");
            isRunning = savedInstanceState.getBoolean("IS_RUNNING");
            delay = savedInstanceState.getLong("DELAY");

            timer.setBase(SystemClock.elapsedRealtime() - convertTime);
        }

        if (isRunning) {
            timer.start();
        } else {

            timer.setBase(SystemClock.elapsedRealtime() - delay);
            timer.stop();
        }
    }

    // Click on button to start timer //
    public void startTimer(View v) {
        if (!isRunning) {
            timer.setBase(SystemClock.elapsedRealtime() - delay);
            timer.start();
            isRunning = true;
        }
    }

    // Click on button to pause timer //
    public void pauseTimer(View v) {
        if (isRunning) {
            timer.stop();
            delay = SystemClock.elapsedRealtime() - timer.getBase();
            isRunning = false;
        }
    }

    // Click on button to stop timer - working - //
    public void stopTimer(View v) {
        CharSequence getTime = timer.getText();
        timer.stop();
        delay = 0;
        timer.setBase(SystemClock.elapsedRealtime());
        isRunning = false;
        displayTimeSpentAndWorkout.setText(String.format("You have spent %s on %s - Great job!\n\n Please enter new activity below and log your time", getTime, workoutEditText.getText().toString()));

        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(WORK_OUT_TYPE, displayTimeSpentAndWorkout.getText().toString());
        editor.apply();
    }

    // Check Shared Preferences working  //
    public void CheckSharedPreferences() {
        String workout = sharedPreferences.getString(WORK_OUT_TYPE, "");
        displayTimeSpentAndWorkout.setText(workout);
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);

        convertTime = SystemClock.elapsedRealtime() - timer.getBase();
        if (!isRunning) {
            timer.stop();
        }
        outState.putLong("DELAY", delay);
        outState.putBoolean("IS_RUNNING", isRunning);
        outState.putLong("CONVERT_TIME", convertTime);
    }
}















  
  
  
  
  


