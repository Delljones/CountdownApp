package com.example.workouttimerapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Chronometer;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
public class MainActivity<paused> extends AppCompatActivity {
    Chronometer timer;
    long delay; 
    boolean isRunning;
    EditText workoutEditText;
    SharedPreferences sharedPreferences, sharedPreferencesTime;
    String WORK_OUT_TYPE, workout;
    long WORK_OUT_TIME, time, timeWorkedOut, timeDisplay;
    TextView displayTimeSpentAndWorkout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        workoutEditText = findViewById(R.id.workoutEditText);
        displayTimeSpentAndWorkout = findViewById(R.id.displayTimeSpentAndWorkout);
        timer = findViewById(R.id.timer);

        // Timer Start//
        timer.setFormat("00:%s");
        timer.setBase(SystemClock.elapsedRealtime());
        timer.setOnChronometerTickListener(new Chronometer.OnChronometerTickListener() {
            @Override
            public void onChronometerTick(Chronometer chronometer) {
                if ((SystemClock.elapsedRealtime() - timer.getBase()) < 0) {
                    chronometer.setBase(SystemClock.elapsedRealtime()); }}});
        // Timer end //
    }

    // Click on button to start timer //
    public void startTimer(View v) {
        if (!isRunning) {
            timer.setBase(SystemClock.elapsedRealtime() - delay);
            timer.start();
            isRunning = true;
        }
    }
    // Click on button to pause timer //
    public void pauseTimer(View v) {
        if (isRunning) {
        timer.stop();
        delay = SystemClock.elapsedRealtime() - timer.getBase();
        isRunning = false; } }

    // Click on button to stop timer //
    public void stopTimer(View v) {
        timer.stop();
        time = SystemClock.elapsedRealtime()- timer.getBase();
        isRunning = false;
        //Stores workout data from last time when stop clicked and shows the variables//
       saveLastWorkout();
       saveLastWorkoutTime();
       showText2();
    }
    // Check Shared Preferences //
    public void saveLastWorkout() {
        sharedPreferences = getSharedPreferences("com.example.workouttimerapp", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(WORK_OUT_TYPE, workoutEditText.getText().toString());
        editor.apply();
        workout = sharedPreferences.getString (WORK_OUT_TYPE, "");
        workoutEditText.setText(workout);
        Toast.makeText(this, "Data Saved " + workout, Toast.LENGTH_LONG).show();
    }
    public void saveLastWorkoutTime() {
        sharedPreferencesTime = getSharedPreferences ("SharedPreferencesTime", MODE_PRIVATE);
        SharedPreferences.Editor editor2 = sharedPreferencesTime.edit();
        time = sharedPreferences.getLong(String.valueOf(WORK_OUT_TIME), timeWorkedOut);
        editor2.apply();
        timeDisplay = sharedPreferencesTime.getLong(String.valueOf(WORK_OUT_TIME), time);

        // Check on the variable //
        Toast.makeText(this, "Your workout data has been saved from last time as " + time, Toast.LENGTH_SHORT).show();
    }
    public void showText1 (){
//       long value = textView.setText(String.valueOf(timeWorkedOut));
        displayTimeSpentAndWorkout.setText("You have spent  on " + time + workout +
             " last time - Great job!\n\n Please enter new activity below and log your time");
    }

    public void showText2 (){

        displayTimeSpentAndWorkout.setText
                ("You have spent  on " + time + workout +
                        " last time - Great job!\n\n Please enter new activity below and log your time");
    }
    }















  
  
  
  
  


